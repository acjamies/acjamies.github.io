/** 
* TitanicIterator.java
* Basic implementation of an Iterator interface specific to the
* TitanicData and TitanicContainer use case. 
*@version January 6th, 2023
*@author Alan Jamieson
*/

package iteratorSoln;

import java.util.Iterator;
import java.util.ArrayList;

public class TitanicIterator implements Iterator<TitanicData> {

	ArrayList<TitanicData> holder;
	int cursor = 0; 
	
	public TitanicIterator(ArrayList<TitanicData >holder) {
		this.holder = holder;
	}
	
	/**
	 * Utilizes the get method from the ArrayList to retrieve an element at
	 * the cursor location. Cursor is then incremented.
	 * @return TitanicData element at index cursor
	 */
	public TitanicData next(){
		return holder.get(cursor++);
	}
	
	/**
	 * Checks the cursor location based off of the size of the internal
	 * container reference.
	 * @return Boolean based on cursor location, checks for if the index would be out of bounds
	 */
	public boolean hasNext() {
		return cursor < holder.size();
	}
}
