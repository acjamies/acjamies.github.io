/** 
* TitanicDriver.java
* Driver and main method to demonstrate use of the Titanic Iterator
* Main reads in the file, stores rows in a TitanicContainer then 
* uses a TitanicIterator to print back out the items stored.
* Current limitation: the exception handling is very messy.
*@version January 6th, 2023
*@author Alan Jamieson
*/

package iteratorSoln;

import java.util.Iterator;
import java.io.BufferedReader;
import java.io.FileReader;

public class TitanicDriver {

	public static void main(String[] args) {
		TitanicContainer t = new TitanicContainer();

		BufferedReader s;
		String line;
		String[] h;
		try {
			s = new BufferedReader(new FileReader("./Titanic.csv"));
			while((line = s.readLine()) != null) {
				h = line.split(",",12);
				t.add(new TitanicData(h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], h[8], h[9], h[10], h[11]));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Iterator<TitanicData> i = t.getIterator();
		
		while(i.hasNext()) {
			System.out.println(i.next().toString());
		}

	}

}
