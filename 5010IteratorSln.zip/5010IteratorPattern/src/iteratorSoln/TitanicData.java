/** 
* TitanicData.java
*Data wrapper class for the Titanic data CSV
*Current limitation: all fields inappropriately are typed as String
*@version January 6th, 2023
*@author Alan Jamieson
*/

package iteratorSoln;

public class TitanicData {
	private String passengerid;
	private String survived;
	private String pclass;
	private String name;
	private String sex;
	private String age;
	private String sibsp;
	private String parch;
	private String ticket;
	private String fare;
	private String cabin;
	private String embarked;
	

	public TitanicData(String passengerid, String survived, String pclass, String name, String sex, String age,
			String sibsp, String parch, String ticket, String fare, String cabin, String embarked) {
		this.passengerid = passengerid;
		this.survived = survived;
		this.pclass = pclass;
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.sibsp = sibsp;
		this.parch = parch;
		this.ticket = ticket;
		this.fare = fare;
		this.cabin = cabin;
		this.embarked = embarked;
	}

	@Override
	public String toString() {
		return "TitanicData [passengerid=" + passengerid + ", survived=" + survived + ", pclass=" + pclass + ", name="
				+ name + ", sex=" + sex + ", age=" + age + ", sibsp=" + sibsp + ", parch=" + parch + ", ticket="
				+ ticket + ", fare=" + fare + ", cabin=" + cabin + ", embarked=" + embarked + "]";
	}
	
	
}
