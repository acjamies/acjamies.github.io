/** 
* TitanicContainer.java
* Basic container class for TitanicData.
* This container uses an ArrayList as an internal representation but could
* be swapped for any dynamically sized data structure. 
*@version January 6th, 2023
*@author Alan Jamieson
*/

package iteratorSoln;

import java.util.ArrayList;
import java.util.Iterator;

public class TitanicContainer {

	private ArrayList<TitanicData> holder;
	
	public TitanicContainer() {
		holder = new ArrayList<TitanicData>();
	}
	
	public void add(TitanicData t) {
		holder.add(t);
	}
	
	public TitanicData get(int i) {
		return holder.get(i);
	}
	
	public TitanicData remove(int i) {
		return holder.remove(i);
	}
	
	public Iterator<TitanicData> getIterator(){
		return new TitanicIterator(holder);
	}
}
