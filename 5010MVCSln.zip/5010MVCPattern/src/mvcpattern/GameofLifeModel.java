/**
 * GameofLifeModel.java
 * Keeps the internal representation of the GoL board (2D char array) as
 * well as all of the update methods for the game.
 * 
 * @version January 11, 2023
 * @author Alan Jamieson
 *
 */

package mvcpattern;

import java.util.Arrays;
import java.util.Random;

public class GameofLifeModel {

	private int height;
	private int width;
	private char[][] board;
	private GameofLifeView view;
	
	/**
	 * Constructor initializes the height and width of the board, creates the array, then
	 * calls 
	 * @param height
	 * @param width
	 */
	public GameofLifeModel(int height, int width) {
		super();
		this.height = height;
		this.width = width;
		board = new char[height][width];
		
		initBoard();
		
		view = new GameofLifeView(this);
		System.out.println("Initial board, L for live, D for dead:");
		view.draw();
	}
	
	/**
	 * @return the board
	 */
	public char[][] getBoard() {
		return board;
	}

	/**
	 * Initialize the board randomly with live and dead tiles.
	 */
	protected void initBoard() {
		
		Random r = new Random();
		
		for (int i = 0; i<board.length; i++) {
			for (int j = 0; j<board[i].length; j++) {
				if (r.nextBoolean())
					board[i][j] = 'L';
				else
					board[i][j] = 'D';
			}
		}
	}
	
	/**
	 * The workhorse of the simulation. Applies the rules for Game of Life, updating the 
	 * board. Note that in a simplification, we store all of the updated tiles in a second
	 * data structure then deep copy it over prior to updating the view. Are there other ways
	 * of doing this where the second board is not necessary?
	 */
	protected void stepUpdate() {
		
		int neighbors = 0;
		char[][] toUpdate = new char[height][width];

		deepCopy(board, toUpdate);
		
		for (int i = 0; i<board.length; i++) {
			for (int j = 0; j<board[i].length; j++) {
				neighbors = countNeighbors(i, j);
				if (neighbors < 2 || neighbors > 3)
					toUpdate[i][j] = 'D';
				if (neighbors == 3)
					toUpdate[i][j] = 'L';
			}
		}
		
		deepCopy(toUpdate, board);
		
		//update the view and display
		viewUpdate();
	}
	
	
	/**
	 * Handles the model update for the view and invokes draw
	 */
	protected void viewUpdate() {
		//this is suspect - the reality is that the passing of the reference to the creation of
		//the view in the constructor should be enough to continuously update the view and that
		//this really does nothing but make pattern purists happy.
		view.updateModel(this);
		
		//this is the actual useful thing that happens in this method
		view.draw();
	}

	/**
	 * Most complicated of the methods, this is the one that calculates the number of neighbors,
	 * and catches the literal edge cases that would cause array out of bounds errors. This is
	 * super messy - can you do better?
	 * @param i - row index
	 * @param j - column index
	 * @return number of neighbors of cell at i, j
	 */
	protected int countNeighbors(int i, int j) {
		int count = 0;
		
		//top left corner
		if(i==0 && j==0) {
			if (board[i+1][j]=='L') count++;
			if (board[i+1][j+1]=='L') count++;
			if (board[i][j+1]=='L') count++;
		}
		//top right corner
		else if(i==0 && j==width-1) {
			if (board[i+1][j]=='L') count++;
			if (board[i+1][j-1]=='L') count++;
			if (board[i][j-1]=='L') count++;
		}
		//bottom left corner
		else if (i==height-1 && j==0) {
			if (board[i][j+1]=='L') count++;
			if (board[i-1][j]=='L') count++;
			if (board[i-1][j+1]=='L') count++;
		}
		//bottom right corner
		else if (i==height-1 && j==width-1) {
			if (board[i][j-1]=='L') count++;
			if (board[i-1][j-1]=='L') count++;
			if (board[i-1][j]=='L') count++;
		}
		//just top row, but not corner
		else if(i==0) {
			if (board[i][j-1]=='L') count++;
			if (board[i][j+1]=='L') count++;
			if (board[i+1][j-1]=='L') count++;
			if (board[i+1][j]=='L') count++;
			if (board[i+1][j+1]=='L') count++;
		}
		//just bottom row, but not corner
		else if(i==height-1) {
			if (board[i][j-1]=='L') count++;
			if (board[i][j+1]=='L') count++;
			if (board[i-1][j-1]=='L') count++;
			if (board[i-1][j]=='L') count++;
			if (board[i-1][j+1]=='L') count++;	
		}
		//just left column, but not corner
		else if(j==0) {
			if (board[i-1][j]=='L') count++;
			if (board[i+1][j]=='L') count++;
			if (board[i-1][j+1]=='L') count++;
			if (board[i][j+1]=='L') count++;
			if (board[i+1][j+1]=='L') count++;
		}
		//just right column, but not corner
		else if(j==width-1) {
			if (board[i-1][j]=='L') count++;
			if (board[i+1][j]=='L') count++;
			if (board[i-1][j-1]=='L') count++;
			if (board[i][j-1]=='L') count++;
			if (board[i+1][j-1]=='L') count++;
		}
		//somewhere in the middle
		else {
			if (board[i-1][j]=='L') count++;
			if (board[i+1][j]=='L') count++;
			if (board[i-1][j-1]=='L') count++;
			if (board[i][j-1]=='L') count++;
			if (board[i+1][j-1]=='L') count++;
			if (board[i-1][j+1]=='L') count++;
			if (board[i][j+1]=='L') count++;
			if (board[i+1][j+1]=='L') count++;
		}
		return count;
	}
	
	/**
	 * Deep copy of 2D char array from src to dest
	 * @param src
	 * @param dest
	 */
	protected void deepCopy(char[][] src, char[][] dest) {
		for(int i = 0; i<src.length; i++) {
			dest[i] = Arrays.copyOf(src[i], src[i].length);
		}
	}
}
