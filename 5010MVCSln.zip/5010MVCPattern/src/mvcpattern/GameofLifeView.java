/**
 * GameofLifeView.java
 * Holds the view class, with the primary responsibility to just
 * draw the game board to the terminal.
 * 
 * @version January 11, 2023
 * @author Alan Jamieson
 *
 */

package mvcpattern;

public class GameofLifeView {
	
	private GameofLifeModel m;

	/**
	 * Intialize with the current model as part of constructor
	 * @param m
	 */
	public GameofLifeView(GameofLifeModel m) {
		this.m = m;
	}

	/**
	 * @param m updating the internal model reference
	 */
	public void updateModel(GameofLifeModel m) {
		this.m = m;
	}
	
	/**
	 * Draws the view, simple print statement double loop.
	 */
	public void draw() {
		
		char[][] board = m.getBoard();
		
		for (int i = 0; i<board.length; i++) {
			for (int j = 0; j<board[i].length; j++) {
				System.out.print(board[i][j] + " ");
			}
			System.out.println("");
		}
	}
	
}
