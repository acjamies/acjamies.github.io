/**
 * GameofLifeDriver.java
 * This represents the Controller portion of the MVC pattern.
 * User will get dimensions of the board then the controller will kick off the simulation
 * initializing the board randomly, then proceeding to simulate step by step.
 * 
 * Limitations: no input validation, no dimension check
 * Also currently relies on user to quit. An interesting check could be incorporated to detect
 * a stable state and quit at that point with a useful message.
 * @author Alan Jamieson
 * @version January 11th, 2023
 *
 */
package mvcpattern;

import java.util.Scanner;

public class GameofLifeDriver {

	/**
	 * @param args - not used
	 */
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int w = 0;
		int l = 0;
		int iteration = 0;
		String in;
		
		System.out.print("Enter height: ");
		l = s.nextInt();
		System.out.print("Enter width: ");
		w = s.nextInt();

		GameofLifeModel m = new GameofLifeModel(l, w);
		
		//run the simulation - q to quit
		while(true) {
			System.out.println("Iteration: "+ iteration++);
			m.stepUpdate();
			System.out.print("Any key and enter to continue, q to quit: ");
			in = s.next();
			if (in.equals("q"))
				break;
		}
		
	}

}
